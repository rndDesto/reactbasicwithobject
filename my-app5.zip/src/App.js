import React, { Component } from 'react';
import './App.css';
import Bahan from './Component/Bahan/Bahan';


class App extends Component {
  render() {
    return (
      <div>
        <Bahan />
      </div>
    );
  }
}

export default App;
